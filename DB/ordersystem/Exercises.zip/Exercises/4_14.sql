INSERT INTO product (PRODUCT_ID, PRODUCT_DESCRIPTION, PRODUCT_FINISH, STANDARD_PRICE) VALUES
(7,'kitchen cabinet','Cherry',1500.00),
(8,'table','Red Oak',550.00)
;

SELECT *
FROM product
;